<?php

$_['text_title'] 		= 'Yapay Intermediador';
$_['text_wait']         = 'Aguarde...';
$_['text_shipping_tax']	= 'Valor de Frete e Taxa';
$_['text_confirm_order'] = 'Confirmar Pedido com Yapay Intermediador';
$_['text_payment'] 	= 'Clique no botão abaixo para ser redirecionado ao Yapay Intermediador e efetuar o pagamento. Após a confirmação de pagamento, será realizado o retorno automático para a loja.';
