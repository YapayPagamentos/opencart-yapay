<?php

class ModelExtensionPaymentTrayCheckout extends Model {
}